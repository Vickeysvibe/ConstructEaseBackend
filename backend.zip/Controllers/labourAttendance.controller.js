import mongoose from "mongoose";
import LabourAttendanceModel from "../Models/LabourAttendance.model.js";
import LabourModel from "../Models/Labors.model.js";
import SupervisorAttendancesModel from "../Models/SupervisorAttendances.model.js";

export const attendance = async (req, res) => {
  try {
    const { labourIds } = req.body;
    const { siteId } = req.query;

    if (!labourIds || labourIds.length === 0) {
      return res.status(400).json({ message: "No labor IDs provided" });
    }

    if (!siteId) {
      return res.status(400).json({ message: "Site ID is required" });
    }

    const validLabors = await LabourModel.find({
      _id: { $in: labourIds },
      siteId,
    }).select("_id");

    if (validLabors.length === 0) {
      return res
        .status(400)
        .json({ message: "No matching labor IDs for the provided site" });
    }

    const validLaborIds = validLabors.map((labor) => labor._id.toString());
    const currentDate = new Date().setHours(0, 0, 0, 0);

    let attendanceDoc = await LabourAttendanceModel.findOne({
      siteId,
      date: currentDate,
    });

    if (!attendanceDoc) {
      attendanceDoc = new LabourAttendanceModel({
        siteId,
        date: currentDate,
        attendance: [],
      });
    }

    const existingLaborIds = attendanceDoc.attendance.map((entry) =>
      entry.labourId.toString()
    );

    const newLaborIds = validLaborIds.filter(
      (id) => !existingLaborIds.includes(id)
    );

    newLaborIds.forEach((labourId) => {
      attendanceDoc.attendance.push({
        labourId,
        status: "present",
        shift: 1,
      });
    });

    await attendanceDoc.save();
    console.log("Attendance document stored");

    const populatedDoc = await LabourAttendanceModel.findOne({
      siteId,
      date: currentDate,
    })
      .populate("attendance.labourId", "name category wagesPerShift")
      .select("attendance");

    const attendanceResponse = populatedDoc.attendance.map((entry) => {
      const labour = entry.labourId;
      const shift = entry.shift || 1;
      const wagesPerShift = labour.wagesPerShift || 0;
      const total = shift * wagesPerShift;

      return {
        Name: labour.name,
        Category: labour.category,
        Shift: shift,
        WagesPerShift: wagesPerShift,
        Total: total,
      };
    });

    res.status(200).json({
      Attendance: attendanceResponse,
    });
  } catch (error) {
    console.error("Error in attendance:", error);
    res.status(500).json({ message: "Internal server error", error });
  }
};

export const getLabours = async (req, res) => {
  try {
    const { siteId } = req.query;

    if (!siteId) {
      return res.status(400).json({ message: "siteId is required" });
    }
    const labourData = await LabourModel.find({ siteId });
    const labourDetails = labourData.map((labour) => ({
      name: labour.name,
      category: labour.category,
      subCategory: labour.subCategory,
      wagesPerShift: labour.wagesPerShift,
    }));

    const subCategoryCounts = await LabourModel.aggregate([
      { $match: { siteId: siteId } },
      {
        $group: {
          _id: { category: "$category", subCategory: "$subCategory" },
          count: { $sum: 1 },
        },
      },
      {
        $group: {
          _id: "$_id.category",
          subCategories: {
            $push: {
              subCategory: "$_id.subCategory",
              count: "$count",
            },
          },
        },
      },
      {
        $project: {
          _id: 0,
          category: "$_id",
          subCategories: "$subCategories",
        },
      },
    ]);

    res.status(200).json({
      labourDetails,
      subCategoryCounts,
    });
  } catch (error) {
    console.error("Error fetching labour data:", error);
    res.status(500).json({ message: "Internal server error", error });
  }
};

export const updateShift = async (req, res) => {
  try {
    const { labourId, newShift } = req.body;
    const { siteId } = req.query;
    const currentDate = new Date().setHours(0, 0, 0, 0); // Normalize date

    if (!labourId || !newShift) {
      return res
        .status(400)
        .json({ message: "Labour ID and new shift are required." });
    }

    if (!siteId) {
      return res.status(400).json({ message: "Site ID is required." });
    }
    const attendanceDoc = await LabourAttendanceModel.findOne({
      siteId,
      date: currentDate,
    });

    if (!attendanceDoc) {
      return res.status(404).json({
        message: "Attendance record not found for the site and date.",
      });
    }

    // Find the specific labor entry in the attendance array
    const laborEntry = attendanceDoc.attendance.find(
      (entry) => entry.labourId.toString() === labourId
    );

    if (!laborEntry) {
      return res
        .status(404)
        .json({ message: "Labour not found in attendance records." });
    }
    laborEntry.shift = newShift;
    await attendanceDoc.save();

    res.status(200).json({ message: "Shift updated successfully." });
  } catch (error) {
    console.error("Error updating shift:", error);
    res.status(500).json({ message: "Internal server error", error });
  }
};

export const getSupervisors = async (req, res) => {
  try {
    const { siteId } = req.query;

    if (!siteId) {
      return res.status(400).json({ message: "Site ID is required." });
    }

    const supervisorsAttendance = await SupervisorAttendancesModel.findOne({
      siteId,
      date: { $gte: new Date("2025-01-21").setHours(0, 0, 0, 0) }, // Normalize date
    }).populate("attendance.supervisorId", "name");
    // .select("location checkin checkout supervisorId ");

    console.log(supervisorsAttendance);
    console.log(supervisorsAttendance.attendance);

    const formattedAttendance = supervisorsAttendance.attendance.map(
      (attendance) => ({
        name: attendance.supervisorId.name,
        location: attendance.location,
        checkinTime: attendance.checkin,
        checkoutTime: attendance.checkout,
      })
    );
    res.status(200).json(formattedAttendance);
  } catch (error) {
    console.error("Error fetching supervisors:", error);
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};
