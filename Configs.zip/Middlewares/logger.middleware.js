import morgan from 'morgan';

const loggerMiddleware = morgan('dev');

export default loggerMiddleware;
